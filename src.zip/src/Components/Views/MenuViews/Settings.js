import React, { Component } from 'react';
import {
    Text
} from 'react-native';
import { Card } from '../../Common';


class Settings extends Component {
    render() {
        return (
            <Card>
                <Text>This is the Settings Page</Text>
            </Card>
        );
    }
}

export { Settings };
