const comments = ([
    {
        user: 'kalbo312',
        comment: 'This has been going on forever! When is someone going\nto fix this issue?',
        points: 42,
        date: 'August 3, 2016'
    },
    {
        user: 'DuterteBoi',
        comment: 'PALITAN TO PARA SA PAGBABAGO!!!!!111',
        points: 13,
        date: 'August 2, 2016'
    },
    {
        user: 'huleka',
        comment: 'I think the mayor has been ignoring this issue for awhile.\nCan we get more visibility on this please?',
        points: 11,
        date: 'August 17, 2016'
    },
    {
        user: 'juandelacruz8',
        comment: 'Ayusin na to!',
        points: 7,
        date: 'August 20, 2016'
    }
]);

export default comments;
