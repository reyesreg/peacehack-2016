import { StyleSheet } from 'react-native';

module.exports = StyleSheet.create({
    container: {
        top: 20
    },
    menuItem: {
        color: 'gray',
        padding: 15,
        marginLeft: 15,
        textAlign: 'left'
    }
});
